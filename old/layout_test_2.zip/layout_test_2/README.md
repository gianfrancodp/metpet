bootstrap-viewer-template
=========================

Some seed bootstrap templates for interactive map viewers. I was sick of basically re-creating these layouts from scratch every time I needed such a layout, so this should hopfefully serve as a nice starting point for anyone building a bootstrap-based map viewer.

 * [2-column layout](//jumpinjackie.github.io/bootstrap-viewer-template/2-column/index.html)
 * [3-column layout](//jumpinjackie.github.io/bootstrap-viewer-template/3-column/index.html)


License
=======

MIT